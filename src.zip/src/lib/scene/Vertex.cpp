//
// Created by tomas on 06.02.22.
//

#include <scene/Vertex.h>
#include <cmath>

