//
// Created by tomas on 03.04.22.
//


#pragma once

#include <string>
#include <vector>

float lerp(float a, float b, float f);

std::vector<unsigned char> readPng(const std::string &path);
